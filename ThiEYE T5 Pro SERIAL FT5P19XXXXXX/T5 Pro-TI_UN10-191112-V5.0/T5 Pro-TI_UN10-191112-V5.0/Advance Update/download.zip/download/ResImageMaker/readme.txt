[ImageCreator v1.0.1.1]
1. fixed bug in Imagecreator of import file error: caused by decrypt file close file earlier.

[ResImageMaker v1.0.2.0][ImageCreator v1.0.2.0]
1. Add scan resource fold and save info to log file.

[ResImageMaker v1.0.3.0][ImageCreator v1.0.3.0][Configuration.dll v1.0.1.0][fatImage.dll v1.0.1.0] 20160831
1. remove "SUNPLUS" and update version

[ResImageMaker v2.0.0.0][ImageCreator v2.0.0.0][Configuration.dll v2.0.0.0][fatImage.dll v1.0.1.0] [XmlModifier v2.0.0.0] 20160930
1. Support .Net4.x

[ResImageMaker v2.0.1.0][ImageCreator v2.0.1.0][Configuration.dll v2.0.0.0][fatImage.dll v1.0.2.0] [XmlModifier v2.0.0.0] 20161024
1. Define Cdecl when DllImport C lib to avoid pinvokestackimbalance error
2. Fix fat size error
